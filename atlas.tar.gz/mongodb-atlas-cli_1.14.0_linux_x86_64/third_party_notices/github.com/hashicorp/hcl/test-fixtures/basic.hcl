foo = "bar"
bar = "${file("bing/bong.txt")}"
