/*
foo = "bar/*"
*/

bar = "value"
