name = "terraform-test-app"

config_vars {
    FOO = "bar"
}
