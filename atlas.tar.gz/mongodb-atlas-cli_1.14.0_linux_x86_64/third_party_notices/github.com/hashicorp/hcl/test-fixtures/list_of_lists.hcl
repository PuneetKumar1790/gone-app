foo = [["foo"], ["bar"]]

