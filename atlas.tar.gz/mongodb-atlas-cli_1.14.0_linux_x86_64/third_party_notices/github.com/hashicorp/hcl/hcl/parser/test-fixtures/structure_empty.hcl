resource "foo" "bar" {}
