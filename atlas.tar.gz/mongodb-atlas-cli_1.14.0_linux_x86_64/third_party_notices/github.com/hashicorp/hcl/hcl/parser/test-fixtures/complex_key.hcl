foo.bar = "baz"
