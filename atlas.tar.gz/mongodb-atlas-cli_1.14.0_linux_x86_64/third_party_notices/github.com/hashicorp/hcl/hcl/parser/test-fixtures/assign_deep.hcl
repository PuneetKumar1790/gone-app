resource = [{
	foo = [{
		bar = {}
	}]
}]
