foo "baz" {
    bar = "baz"
